# <span style="color:red"> Cloning of [Deyga](https://deyga.in/) WEBSITE</span>

# <span style="color:red"> Welcome Here!</span>

Hello Readers,<br>
It was during the final week which is depicted as the construct week. We have done this project with group of 5 members and build the clone of a very popular Online website  which creating sells nature-inspired, self care products.<br>This Project is our construct week project in Unit-3 an we give a name to our project called Deyga Project. 
<br> I hope you will enjoy the reading….

# <span style="color:red"> About Website: </span>

 [Deyga](https://deyga.in/), Choose from a Wide Range of Natural Cosmetics from India's Favourite Brand. From Start To Finish With Purest Of Ethically Sourced Organic Matter. Easy Returns. 24X7 Customer Service. 100% Natural & Pure. Hand Made Products. Handcrafted with Love.<br>
 Link := https://intense-shore-24711.herokuapp.com/

# <span style="color:red"> Tech Stack Used: </span>

We have used Html5, CSS, Advance JavaScript,Local Storage for building this Project. We also used tools like GitHub for collaboration of our project, Slack & Zoom as means of a communication channel.


# <span style="color:red"> Details of Tech stack used: </span>

<b>HTML5:</b>

we have used to build the basic structure of the website. All headings, Paragraphs, links, forms, etc. were structured by HTML.

 <b>CSS:</b>

We have used to add styling to the website. We used Advance CSS for Popup Modal window for login/Sign up, Payment, and all other styling.

 <b> Advance JavaScript:</b>

We have used to add logical functionalities to the web pages like the on Click function. We have added all the functionalities.

<b> Local storage:</b>

We have used local-storage as a database for storing users’ data, products details, and cart details.<br>

<b> Rest Api:</b>

Let us share our experience,<br>
This entire journey of making the project was awesome. We have learned lots of things by applying to the real website and it gave us a lot of confidence. there were some more functionalities that could have been done, yeah the time didn’t permit us to go further. But we will surely improve it during the course of time in future .

## So jurney started from here!

### Snapshots of our project :- 

- ## <span style="color:blue"> Home Page </span>

<img width="377" alt="Home page" src="https://miro.medium.com/max/1400/1*hOqavOAFqBGQiuQLr_PO4Q.png">



- ## <span style="color:blue"> Product Pages</span>

<img width="400" alt="zms 1" src="https://miro.medium.com/max/1400/1*0LXgA-ybiktD0yB16L1eog.png">
<img width="400" alt="zms 1" src="https://miro.medium.com/max/1400/1*3i0wmdzWLUsOvq1zRAYrJA.png">
<img width="400" alt="zms 1" src="https://miro.medium.com/max/1400/1*GYqoRZuIzr7zJcF04moxQQ.png">


- ## <span style="color:blue"> Bill Page</span>

 <img width="391" alt="zms footer" src="https://miro.medium.com/max/1400/1*F1rVwueZw6uUb5KPh9FS5Q.png">
 
 
<br>
 <hr>

 <br>

# <span style="color:red">Our Journey: </span>
As we are all new and never work on a project so our first day gone in discussion about how we start and who did which work, In evening finally we decide distribute our work.
On the second day we start with our morning scrum and decide the deadline to complete the whole project and start working on it, the In evening stand-up we discussed our challenges and problem and try to resolve them.
2 days we have the same routine and finally on the fourth day our given task is ready but when we merge the all parts the main problem came like many classes and ids are same due to that the structure of all products was very bad but our Team take it as a challenge and change and put comments on code in just one and half day.
on the seventh day again we merge all our code and finally, we did it, There were some changes that need to be done and we all did it and finally, we record our presentation and Submit.
<br>


# <span style="color:red">Conclusion: </span>
We are very thankful for the support of my teammates and instructor for the completion of project in due time. We will looks forward to add some feature and functionality which we left in this project for future expensions.


# <span style="color:red"> Thank Your For Reading </span>


## <span style="color:red"> Team Members: </span>

- ## Ayush Kumar Jha
[GitHub](https://github.com/Aayush771)

- ## Saumitra Upadhyay
[GitHub](https://github.com/saumitra-vns)

- ## Subhankar Sarkar
[GitHub](https://github.com/sarkarsubho)

- ## Tanmoy Mondal
[GitHub](https://github.com/Tanmoy-M17)

- ## Sheel Kumar
[GitHub](https://github.com/sheelkumar558)


